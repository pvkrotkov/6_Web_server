import json
from http import server
import os
import datetime


class CustomHandler(server.SimpleHTTPRequestHandler):

    def do_GET(self):
        self.send_response(200)
        self.send_header('content-type', 'text/html')
        self.end_headers()
        path = self.path
        if path == '/':
            path = 'index'
        else: path=path[1:]

        print(path)

        try:
            file  = open(path + ".html", 'r')
            # print(file)
        except FileNotFoundError:
            file  = open("folder/404.html", 'r')
        message = file.read()
        file.close()
        self.wfile.write(bytes(message, "utf8"))


    def do_POST(self):
        self.send_response(200)
        self.send_header('content-type', 'application/json')
        self.send_header('Server', 'CoolServer')
        self.end_headers()
        self.wfile.write(json.dumps({'result': True}).encode())

    def do_PUT(self):
        self.send_response(200)
        self.send_header('content-type', 'text/plain')
        self.end_headers()
        self.wfile.write(b'PUT request\n')


port = int(input("Input number port: "))
server_address = ('localhost', port)

httpd = server.HTTPServer(server_address, CustomHandler)
httpd.serve_forever()
